package mar.Tarea.Veterinaria.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import mar.Tarea.Veterinaria.model.entity.Cita;
import mar.Tarea.Veterinaria.service.ICita;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api")
public class CitaController {

	@Autowired
	private ICita citaService;
	
	
	@PostMapping("cita")
	public Cita create(@RequestBody Cita cita) {		
		return citaService.save(cita);
	}
	
	@PutMapping("cita")
	public Cita update(@RequestBody Cita cita) {		
		return citaService.save(cita);
	}
	
	
	@DeleteMapping("cita/{id}")
	public void delete(@PathVariable Integer id) {
		Cita citaDelete = citaService.findById(id);
		citaService.delete(citaDelete);
	}
	
	
	@GetMapping("cita/{id}")
	public Cita showById(@PathVariable Integer id) {
		return citaService.findById(id);
	}
	
	
	@GetMapping("producto")
	public Iterable<Cita> show() {
		return citaService.findAll();
	}
}
